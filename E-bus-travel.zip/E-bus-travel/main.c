#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define MAX_Voyageurs 50

typedef struct voyageur voyageur;
struct voyageur {
    int num_tel; 
    char nom[20];
    char prenom[20];
    
};

typedef struct bus bus;
struct bus
{
    int ID;
    int cap;
    char etat[20];
    char loc[50];
};

typedef struct noeud noeud;
struct noeud {
    voyageur val;
    noeud* suiv;
    
};
typedef noeud* listeV;

typedef struct voyage voyage;
struct voyage
{
    int id;
    char dest[10];
    char loc[50];
    bus b;
    char date[20];
    char date_arr[20];
    int nb_places;
    float tarif;
    voyageur l[MAX_Voyageurs];
};

typedef struct reservation reservation;
struct reservation
{
    voyageur v;
    voyage voy;
    char dt_res[50];
};

listeV ajout_voyageur(voyageur v, listeV L) {
    listeV p = malloc(sizeof(noeud));
    if (p == NULL) {
        printf("Erreur lors de l'allocation mémoire\n");
        return L; // Retourne la liste inchangée en cas d'échec d'allocation
    }
    p->suiv = L;
    p->val = v;
    return p; // Retourne la nouvelle tête de liste
}


void creer_compte(){
    FILE *fichier;
    voyageur v;
    fichier = fopen("voyageurs.bin","ab");
    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier voyageurs.bin\n");
        return;
    }
    printf("\ndonner votre numero de telephone :");
    scanf("%d",&v.num_tel);
    printf("donner votre nom :");
    scanf("%s",v.nom);
    printf("donner votre prenom :");
    scanf("%s",v.prenom);
    printf("compte creer avec succes!\n");
    fwrite(&v,sizeof(voyageur),1,fichier);
    fclose(fichier);
}

void ajouter_bus(){
    FILE *f;
    bus b;
    f = fopen("bus.bin","ab");
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier bus.bin\n");
        return;
    }
    printf("donner les details d'un bus:\n");
    printf("ID(4 chiffres):");
    scanf("%d",&b.ID);
    printf("localisation:");
    scanf("%s",b.loc);
    printf("capacite:");
    scanf("%d",&b.cap);
    strcpy(b.etat,"disponible");
    fwrite(&b,sizeof(bus),1,f);
    fclose(f);
}

void affiche_bus() {
    FILE *f, *g;
    bus b;
    voyage voy;
    f = fopen("bus.bin", "rb");
    g = fopen("voyages.bin", "rb");
    if (f == NULL || g == NULL) {
        printf("Erreur lors de l'ouverture des fichiers bus.bin ou voyages.bin\n");
        return;
    }
    printf("+----+----------+----------+--------------+------------------+-------------+----------------+--------------+\n");
    printf("| ID | capacite |   etat   | localisation | numero du voyage | destination | date de depart | date arrivee |\n");
    printf("+----+----------+----------+--------------+------------------+-------------+----------------+--------------+\n");

    while (fread(&b, sizeof(bus), 1, f) == 1) {
        int found = 0;
        rewind(g); // Reset the file pointer to the beginning
        while (fread(&voy, sizeof(voyage), 1, g) == 1) {
            if ((b.ID == voy.b.ID) && strcmp(b.etat,"disponible")==1) {
                printf("|%-2d|%-10d|%-10s|%-14s|%-16d  |%-12s |%-15s |%-14s|\n", b.ID, b.cap, b.etat, voy.loc, voy.id, voy.dest,voy.date,voy.date_arr);
                found = 1;
                break;
            }
        }
        if (!found && strcmp(b.etat, "disponible") == 0) {
            printf("|%-4d|%-10d|%-10s|%-14s|                  |             |                |              |\n", b.ID, b.cap, b.etat, b.loc);
        }
    }
    printf("+----+----------+----------+--------------+------------------+-------------+----------------+--------------+\n");

    fclose(f);
    fclose(g);
}

bus select_bus(char loc[10]){
    FILE *f;
    bus b;
    int idb;
    affiche_bus();
    printf("\n Donner l'ID du bus a choisir:");
    scanf("%d",&idb);
    f=fopen("bus.bin","rb");
    while(fread(&b,sizeof(bus),1,f)==1){
        if ((strcmp(b.etat,"disponible")==0) && b.ID==idb && (strcmp(b.loc,loc)==0)) {
            fclose(f);
            return b;  
        }
    }
    fclose(f);
    printf("pas de bus disponible\n");
    b.ID=0;
    return b;


}

void change_etat_bus(int id){
    FILE *f;
    FILE *g;
    bus b;
    char etat[10]="en voyage";
    f=fopen("bus.bin","rb");
    g=fopen("n_bus.bin","wb");
    while (fread(&b,sizeof(bus),1,f)==1)
    {
        if (b.ID==id){
            strcpy(b.etat, etat);
            fwrite(&b,sizeof(bus),1,g);
        }
        else{
            fwrite(&b,sizeof(bus),1,g);
        }
    }
    fclose(g);
    fclose(f);
    remove("bus.bin");
    rename("n_bus.bin","bus.bin");

}

void retour_bus(){
    FILE *f,*g;
    bus b;
    int id,a;
    int trouve=0;
    printf("donner l'id du bus qui a retourner:");
    a=scanf("%d",&id);
    if (a!=1){
        printf("id invalide essayer une autre fois");
        return;
    }
    f=fopen("bus.bin","rb");
    g=fopen("n_bus.bin","wb");
    while (fread(&b,sizeof(bus),1,f)==1){
        if (b.ID==id){
            strcpy(b.etat,"disponible");
            trouve=1;
        }
        fwrite(&b,sizeof(bus),1,g);
        
    }
    if (!trouve){
        printf("le bus n'est pas trouvee.");
    }
    fclose(f);
    fclose(g);
    remove("bus.bin");
    rename("n_bus.bin","bus.bin");
    
}

void organiser_voyage() {
    voyage v,v1;
    FILE *f;
    bus b;
    int idv=0;
    char loc[50];
    printf("donner le lieu de depart:");
    scanf("%s",loc);
    b = select_bus(loc);
    strcpy(b.etat,"en voyage");
    if (b.ID != 0) {
        change_etat_bus(b.ID);
        f=fopen("voyages.bin","rb");
        
        if (f != NULL){
            while (fread(&v1,sizeof(voyage),1,f)==1)
            {
                idv=v1.id;
            }
            idv++;
        }
        fclose(f);
        do {
            printf("donner les infos de voyage\n");
            printf("destination:");
            scanf("%s", v.dest);
            printf("date de depart:");
            scanf("%s", v.date);
            printf("date d'arrive:");
            scanf("%s",v.date_arr);
            printf("tarif:");
            scanf("%f", &v.tarif);
            v.b = b;
            strcpy(v.loc,loc);
            v.nb_places = b.cap;
            v.id=idv;

            // Sortir de la boucle une fois que les informations sont saisies
            if (v.id != 0 && strcmp(v.dest, "") != 0 && strcmp(v.date, "") != 0 && v.tarif != 0) {
                break;
            }
            printf("Saisie incorrecte. Réessayez.\n");
        } while (1); // Boucle tant que les informations ne sont pas saisies correctement
        
        f = fopen("voyages.bin", "ab");
        if (f == NULL) {
            printf("Erreur lors de l'ouverture du fichier voyages.bin\n");
            return;
        }

        fwrite(&v, sizeof(voyage), 1, f);
        fclose(f);
    }
}

void dec_nbplaces_voyage(int id) {
    FILE *f, *g;
    voyage v;
    int trouve = 0; // Indicates if the voyage has been found

    f = fopen("voyages.bin", "rb");
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier voyages.bin\n");
        return;
    }

    g = fopen("n_voyages.bin", "wb");
    if (g == NULL) {
        printf("Erreur lors de l'ouverture du fichier n_voyages.bin\n");
        fclose(f);
        return;
    }

    while (fread(&v, sizeof(voyage), 1, f) == 1) {
        if (v.id == id) {
            if(v.nb_places>0){
            v.nb_places--;
            trouve = 1; // Indicates that the voyage has been found and modified
            }
        }
        fwrite(&v, sizeof(voyage), 1, g); // Write all records to the new file
    }

    fclose(g);
    fclose(f);

    if (!trouve) {
        printf("Le voyage avec l'ID donné n'a pas ete trouve ou pas de place.\n");
        remove("n_voyages.bin");
        return;
    }

    remove("voyages.bin");
    if (rename("n_voyages.bin", "voyages.bin") != 0) {
        printf("Erreur lors du remplacement du fichier voyages.bin\n");
        return;
    }

}

void inc_nbplaces_voyage(int id){
     FILE *f, *g;
    voyage v;
    int trouve = 0; // Indicates if the voyage has been found

    f = fopen("voyages.bin", "rb");
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier voyages.bin\n");
        return;
    }

    g = fopen("n_voyages.bin", "wb");
    if (g == NULL) {
        printf("Erreur lors de l'ouverture du fichier n_voyages.bin\n");
        fclose(f);
        return;
    }

    while (fread(&v, sizeof(voyage), 1, f) == 1) {
        if (v.id == id) {
            if (v.nb_places<v.b.cap){
            v.nb_places++;
            trouve = 1; // Indicates that the voyage has been found and modified
            }
            
            
        }
        fwrite(&v, sizeof(voyage), 1, g); // Write all records to the new file
    }

    fclose(g);
    fclose(f);

    if (!trouve) {
        printf("Le voyage avec l'ID donne n'a pas ete trouvé.\n");
        remove("n_voyages.bin");
        return;
    }

    remove("voyages.bin");
    if (rename("n_voyages.bin", "voyages.bin") != 0) {
        printf("Erreur lors du remplacement du fichier voyages.bin\n");
        return;
    }
}

void affiche_voyages() {
    FILE *f;
    voyage v;
    f = fopen("voyages.bin", "rb");
    if (f != NULL) {
        printf("+-----+----------------+-------------+----------------+--------------+-------+-----------------+\n");
        printf("| ID  | lieu de depart | Destination | Date de depart | date arrivee | Tarif | Nombre de places|\n");
        printf("+-----+----------------+-------------+----------------+--------------+-------+-----------------+\n");
        while (fread(&v, sizeof(voyage), 1, f) == 1) {
            printf("| %-4d|%-16s| %-12s| %-15s| %-13s| %-6.2f| %-16d|\n", v.id, v.loc, v.dest, v.date,v.date_arr, v.tarif, v.nb_places);
        }
        printf("+-----+----------------+-------------+----------------+--------------+-------+-----------------+\n");
        fclose(f);
    } else {
        printf("pas de voyage\n");
    }
}

void reserver(listeV *l){
    time_t currentTime;
    struct tm *localTime;
    char timeString[20];
    voyageur v1,v2;
    voyage voy;
    int id;
    FILE *f;
    FILE *g;
    FILE *h;
    int b=0;
    reservation r;
    printf("\nnumero telephone :");
    scanf("%d",&v1.num_tel);
    f=fopen("reservations.bin","ab");
    g=fopen("voyageurs.bin","rb");
    
    while (fread(&v2,sizeof(voyageur),1,g)==1)
    {
        if (v2.num_tel==v1.num_tel){
            b=1;
            break;
        }
    }
    if (b==0){
        printf("pas de compte voyageur creer une .");
    }
    else{
        int c=0;
        do
        {

        affiche_voyages();
        h=fopen("voyages.bin","rb");
        printf("\ndonner l'ID du voyage a resever :");
        scanf("%d",&id);
        while (fread(&voy,sizeof(voyage),1,h)==1)
        {
            if (voy.id==id){
                c=1;
                break;
            }
        }
        if (c==0){
            printf("id du voyage incorrect esssayer un autre fois\n");
            break;
        }
        }while (c==0);
        fclose(h);
        *l = ajout_voyageur(v2, *l);
        dec_nbplaces_voyage(id);
        r.voy=voy;
        r.v=v2;
        currentTime = time(NULL);
        localTime = localtime(&currentTime);
        strftime(timeString, sizeof(timeString), "%d-%m-%Y %H:%M", localTime);
        strcpy(r.dt_res,timeString);
        fwrite(&r,sizeof(reservation),1,f);
        fclose(f);
        fclose(g);
        printf("\ndone!");
        
    }

}

int affiche_reservation(int tel){
    int b=0;
    reservation r;
    FILE *f;
    f=fopen("reservations.bin","rb");
    printf("+----------------+-----------+-------------------+--------------+-----+-----------+\n");
    printf("|Numero_du_voyage|destination|date_de_reservation|date_de_depart|tarif| ID du bus |\n");
    printf("+----------------+-----------+-------------------+--------------+-----+-----------+\n");
    while(fread(&r,sizeof(reservation),1,f)==1){
        if (r.v.num_tel==tel){
            printf("|%-16d|%-11s|%-18s |%-14s|%-5.2f|%-11d|\n",r.voy.id,r.voy.dest,r.dt_res,r.voy.date,r.voy.tarif,r.voy.b.ID);
            b=1;
        }
        
    }
    printf("+----------------+-----------+-------------------+--------------+-----+-----------+\n");
    if (b==0){
        printf("\nvous n'avez pas reserver.");
    }

fclose(f);
return b;


}

void annule_reservation(){
    int tel, id;
    int b = 0;
    reservation r;
    voyage v;
    FILE *f, *g;
    printf("Donner votre numero de telephone:");
    scanf("%d",&tel);
    b=affiche_reservation(tel);
    if (b!=0){
    f = fopen("reservations.bin", "rb");
    g = fopen("temp.bin", "wb");
    
    printf("Entrez l'ID du voyage  : ");
    scanf("%d", &id);
    
    while (fread(&r, sizeof(reservation), 1, f) == 1) {
        if (r.v.num_tel == tel && r.voy.id == id) {
            b = 1; // Marque que la réservation a été trouvée
            
            // On ne copie pas la réservation à annuler dans le fichier temporaire
        } else {
            fwrite(&r, sizeof(reservation), 1, g); // Copie les autres réservations
        }
    }

    fclose(f);
    fclose(g);
    remove("reservations.bin");
    rename("temp.bin", "reservations.bin");

   
    
    
    }
    else{
        printf("pas de reservation.");
    }
}

void affiche_voyageur(listeV l) {
    listeV p;
    p=l;
    if (p!=NULL){
    printf("+----------------+---------+----------+\n");
    printf("|Numero telephone|   Nom   |  Prenom  |\n");
    printf("+----------------+---------+----------+\n");
    while (p!=NULL) {
                printf("|%-16d|%-9s|%-10s|\n", p->val.num_tel, p->val.nom, p->val.prenom);
                p=p->suiv;
            }

            printf("+----------------+---------+----------+\n");
    }
    else{
        printf("pas de voyageur\n");
    }
}
    




int main() {
    int choice;
    int b;
    listeV l;
    l=NULL;
    do {
        do{
        printf("\nHome\n");
        printf("1. Client\n");
        printf("2. Administrateur\n");
        printf("3. Exit\n");
        printf("choix :");
        b=scanf("%d", &choice);
        // If scanf fails to read an integer or receives incorrect input
        if (b != 1) {
            printf("Invalid input. Please enter a valid choice.\n");
            

            while (getchar() != '\n');
        }
        }while(b==0);
        switch (choice) {
            case 1:
                do{
                    do{
                    printf("\nMenu:\n");
                    printf("1. creer un compte voyageur\n");
                    printf("2. reserver une voyage\n");
                    printf("3. voir mon reservation\n");
                    printf("4. annuler une reservation\n");
                    printf("5. retourner\n");
                    printf("choix :");
                    b=scanf("%d", &choice);
                    if (b != 1) {
                        printf("choix invalide ,essayer une autre fois.\n");
                        
                        // Clear the input buffer
                        while (getchar() != '\n');
                    }
                    }while(b==0);
                    switch (choice) {
                        case 1:
                            creer_compte();
                            break;
                        case 2:
                            reserver(&l);
                            break;
                        case 3:
                            int tel;
                            printf("donner votre numero de telephone:");
                            scanf("%d",&tel);
                            affiche_reservation(tel);
                            break;
                        case 4:
                            annule_reservation();
                            break;
                        case 5:
                            break;
                        default:
                            printf("choix invalide. essayer une autre fois.\n ");
                            break;
                    }
                } while (choice != 5);
                break;

            case 2:
                char util[10];
                char mdp[10];
                char bl = 'A';

                do {
                    printf("nom utilisateur :");
                    scanf("%s", util);
                    printf("mot de passe :");
                    scanf("%s", mdp);

                    if (strcmp(util, "admin") == 0 && strcmp(mdp, "admin") == 0) {
                        break; // Si les identifiants sont corrects, sortir de la boucle
                    } else {
                        printf("\nlogin invalide.\n");
                        printf("\nsaisir 'E' pour sortir et un autre caractere pour essayer une autre fois.");
                        scanf(" %c", &bl); // Ajout d'un espace avant %c pour consommer le caractère de nouvelle ligne restant
                    }
                } while (bl != 'E');

                if (bl != 'E') {
                    do {
                        do{
                        printf("\nMenu:\n");
                        printf("1. ajouter un bus\n");
                        printf("2. afficher les bus\n");
                        printf("3. organiser une voyage\n");
                        printf("4. afficher les voyages\n");
                        printf("5. afficher les voyageurs\n");
                        printf("6. declarer le retour d'un bus\n");
                        printf("7. retourner\n");
                        printf("choix :");
                        b=scanf("%d", &choice);
                        if (b != 1) {
                        printf("choix invalide. essayer une autre fois.\n");
                    
                        // Clear the input buffer
                        while (getchar() != '\n');
                        }   
                }while(b==0);
                        switch (choice) {
                            case 1:
                                ajouter_bus();
                                printf("\nDone!");
                                break;
                            case 2:
                                affiche_bus();
                                break;
                            case 3:
                                organiser_voyage();
                                printf("\nDone!");
                                break;
                            case 4:
                                affiche_voyages();
                                break;
                            case 5:
                                affiche_voyageur(l);
                                break;
                            case 6:
                                affiche_bus();
                                retour_bus();
                                break;
                            case 7:
                                break;
                            default:
                                printf("\nchoix invalide, essayez une autre fois");
                                break;
                        }

                    } while (choice != 7);
                }
                break;

            case 3:
                printf("\nExiting...");
                break;

            default:
                printf("choix invalide, essayez une autre fois.\n");
                break;
        }
    } while (choice != 3 );

    return 0;
}